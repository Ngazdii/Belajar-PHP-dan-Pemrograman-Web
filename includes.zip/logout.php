<?php
session_start();

unset($_SESSION['id_user']);
unset($_SESSION['nama']);
unset($_SESSION['username']);

header("Location: login.php");
exit;
?>